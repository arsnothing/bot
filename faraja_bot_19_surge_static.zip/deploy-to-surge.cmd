@echo off
setlocal
set "SITE_DIR=%~dp0"

if not exist "%SITE_DIR%index.html" (
  echo ERROR: index.html was not found next to this script.
  pause
  exit /b 1
)

where npx >nul 2>&1
if errorlevel 1 (
  echo ERROR: Node.js and npx are required to deploy with Surge.
  echo Install Node.js LTS or use a portable Node.js ZIP, then try again.
  pause
  exit /b 1
)

echo Deploying the static site from:
echo %SITE_DIR%
echo.
echo If you are not logged in, Surge will ask you to log in here.
npx --yes surge "%SITE_DIR%" faraja-bot.surge.sh

echo.
pause
