Static Surge preview build. Server-side PHP report submission is intentionally disabled.
