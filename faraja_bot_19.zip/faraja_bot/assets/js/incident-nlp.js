/*
 * استخراج سبکِ عنوان سناریو از متن گفتار
 * ---------------------------------------
 * این کمک‌یار فقط یک عنوان را پیشنهاد می‌کند و پاسخ‌های آن را برای بازبینی
 * کاربر پیش‌نویس می‌سازد. هیچ پاسخ خودکار، ثبت نهایی را جایگزین نمی‌کند.
 */
(function () {
  const KEYWORDS_BY_LABEL = Object.freeze({
    'جرائم زیست محیطی': ['محیط زیست', 'شکار', 'آلودگی', 'گونه'],
    'تعدی مامورین دولتی': ['مامور', 'مأمور', 'دستگاه دولتی'],
    'جرائم سایبری': ['سایبری', 'هک', 'حساب کاربری', 'اینترنت'],
    'جرائم عمومی علیه اموال و اشخاص': ['سرقت', 'دزدی', 'سارق', 'آسیب به مال'],
    'تیراندازی': ['تیراندازی', 'شلیک', 'گلوله'],
    'بهره برداری غیرمجاز': ['بهره برداری', 'بهره‌برداری', 'غیرمجاز'],
    'ادم ربایی': ['آدم ربایی', 'آدم‌ربایی', 'ربودن'],
    'پیدایش اجساد ناشناس': ['جسد ناشناس', 'جنازه ناشناس'],
    'حوادث و سوانح غیر عمدی': ['حادثه', 'سانحه', 'غیر عمدی'],
    'امور امنیتی مجاز': ['امنیتی مجاز', 'مجوز امنیتی'],
    'امور خاص اتباع بیگانه_ دیپلمات': ['دیپلمات', 'سفارت', 'تبعه بیگانه'],
    'مشاهدات وقایع مرزی': ['مرز', 'مرزی'],
    'امور مالی و ملکی': ['مالی', 'ملکی', 'ملک', 'زمین'],
    'درگیری مسلحانه': ['درگیری مسلحانه', 'سلاح', 'تبادل آتش'],
    'وقایع و فراخوان سایبری': ['فراخوان سایبری', 'دعوت اینترنتی', 'هشتگ'],
    'حوادث مرتبط با با مواد محترقه غیر مجاز': ['مواد محترقه', 'ترقه', 'آتش بازی'],
    'جرائم علیه امنیت داخلی و خارجی': ['امنیت داخلی', 'امنیت خارجی', 'ضد امنیتی'],
    'جرائم برخلاف تکالیف نظامی': ['نظامی', 'سرباز', 'پادگان'],
    'جرائم مرتبط با فرار': ['فرار', 'متواری'],
    'جرائم علیه تمامیت اشخاص': ['آسیب بدنی', 'صدمه', 'ضرب و جرح'],
    'جرائم علیه شخصیت معنوی و اشخاص و آزادی تن': ['آزادی تن', 'بازداشت غیرقانونی', 'هتک حیثیت'],
    'جرائم علیه اموال و مالکیت': ['اموال', 'مالکیت', 'دزدی'],
    'جرائم علیه نظم و آسایش عمومی': ['نظم عمومی', 'مزاحمت', 'آرامش عمومی'],
    'جرائم مرتبط با مواد مخدر_ قاچاق و تبانی': ['مواد مخدر', 'قاچاق مواد', 'تبانی'],
    'جرائم ضد عفت و اخلاق عمومی': ['اخلاق عمومی', 'عفت عمومی'],
    'جرائم مرتبط با رانندگی و وسایل نقلیه': ['رانندگی', 'وسیله نقلیه', 'خودرو'],
    'جرائم مرتبط با جعل و تزویر': ['جعل', 'سند جعلی', 'تزویر'],
    'جرائم مربوط به سوءاستفاده از شغل': ['سوءاستفاده از شغل', 'سوء استفاده شغلی'],
    'جرائم مرتبط با ضابطین': ['ضابط', 'مامور', 'مأمور'],
    'جرائم رایانه ای': ['رایانه', 'بدافزار', 'هک'],
    'جرائم پزشکی و بهداشتی': ['پزشکی', 'درمان', 'دارو'],
    'فراخوان ها': ['فراخوان', 'دعوت عمومی'],
    'تخلفات بهداشتی': ['بهداشتی', 'آلودگی غذا', 'سلامت'],
    'اعتراض مسافرین': ['مسافر', 'اعتراض مسافران'],
    'مفاسد اجتماعی': ['مفاسد اجتماعی', 'فساد اجتماعی'],
    'سرقت نزاع و درگیری': ['سرقت', 'دزدی', 'سارق', 'نزاع', 'درگیری'],
    'شرارت': ['شرارت', 'مزاحمت'],
    'جعل و تقلب': ['جعل', 'تقلب'],
    'غصب شغل و عناوین': ['غصب عنوان', 'عنوان جعلی', 'شغل جعلی'],
    'قاچاق': ['قاچاق', 'کالای قاچاق'],
    'مواد مخدر': ['مواد مخدر', 'تریاک', 'هروئین', 'حشیش'],
    'خودکشی': ['خودکشی', 'آسیب به خود'],
    'تهدید و اکراه': ['تهدید', 'اکراه'],
    'حوادث و سوانح عمدی': ['عمدی', 'خرابکاری'],
    'امور امنیتی و غیر‌مجاز': ['امنیتی', 'غیرمجاز'],
    'امور خاص اتباع بیگانه': ['اتباع بیگانه', 'تبعه خارجی'],
    'جرائم مالی و اقتصادی': ['مالی', 'اقتصادی'],
    'جرائم و تخلفات راهور': ['راهور', 'رانندگی', 'تخلف رانندگی'],
    'تخلفات و جرائم صنفی': ['صنفی', 'مغازه', 'واحد تجاری'],
    'جرائم ملکی': ['ملکی', 'ملک', 'زمین'],
    'اختلافات خانوادگی': ['خانوادگی', 'خانواده'],
    'انفجار': ['انفجار', 'منفجر', 'ترکید', 'بمب', 'مواد منفجره'],
    'آتش‌سوزی': ['آتش‌سوزی', 'آتش سوزی', 'اتش سوزی', 'حریق', 'شعله', 'دود'],
    'سرقت': ['سرقت', 'دزدی', 'سارق', 'دزد'],
    'نزاع دسته‌جمعی': ['نزاع دسته‌جمعی', 'نزاع دسته جمعی', 'نزاع دست جمعی', 'درگیری دسته‌جمعی', 'درگیری دسته جمعی', 'دعوا', 'زدوخورد'],
    'فروش مواد مخدر': ['فروش مواد مخدر', 'فروش مواد', 'فروشنده مواد', 'مواد مخدر می‌فروخت'],
    'فروش مشروبات الکلی': ['فروش مشروبات الکلی', 'مشروبات الکلی', 'فروش مشروب', 'فروش الکل'],
    'قاچاق انسان': ['قاچاق انسان', 'قاچاق آدم', 'بهره‌کشی', 'بهره کشی', 'کار اجباری'],
    'قاچاق سلاح و مهمات': ['قاچاق سلاح و مهمات', 'قاچاق سلاح', 'قاچاق اسلحه', 'قاچاق مهمات'],
    'احتکار': ['احتکار', 'دپو', 'انبار احتکار'],
    'خانه فساد': ['خانه فساد', 'محل فساد']
  });

  const CHOICE_SYNONYMS = Object.freeze({
    'بله': ['بله', 'آره', 'دارد', 'وجود دارد'],
    'خیر': ['خیر', 'نه', 'ندارد', 'وجود ندارد'],
    'نامشخص': ['نامشخص'],
    'قاچاق اعضای بدن': ['اعضای بدن'],
    'جنسی': ['جنسی'],
    'اتباع': ['اتباع']
  });

  function splitSentences(text) {
    return String(text || '')
      .split(/[.!؟\n]+/)
      .map(sentence => sentence.trim())
      .filter(Boolean);
  }

  function scenarioTerms(topic) {
    const terms = [topic.label, topic.search || ''];
    const custom = KEYWORDS_BY_LABEL[topic.label] || [];
    return [...new Set([...terms, ...custom].map(value => String(value || '').trim()).filter(Boolean))];
  }

  function topicScore(topic, text) {
    // Naming a scenario explicitly is stronger evidence than a generic shared
    // keyword (for example, «مواد مخدر» should prefer that exact title).
    const explicitLabelScore = text.includes(topic.label) ? 20 : 0;
    return explicitLabelScore + scenarioTerms(topic)
      .reduce((score, term) => {
        if (!text.includes(term)) return score;
        // A specific multi-word phrase outranks a broad shared keyword such as
        // «درگیری» or «قاچاق» when the reporter has supplied that detail.
        return score + (term.replace(/\s/g, '').length >= 7 ? 4 : 1);
      }, 0);
  }

  function selectedChoice(items, text) {
    for (const item of items || []) {
      if (text.includes(item)) return item;
      if ((CHOICE_SYNONYMS[item] || []).some(alias => text.includes(alias))) return item;
    }
    return '';
  }

  function questionCueTerms(question) {
    if (Array.isArray(question.cues) && question.cues.length) return question.cues;
    const key = String(question.key || '');
    if (/(location|place|address|route|origin|destination|transit)/i.test(key)) {
      return ['محل', 'مکان', 'آدرس', 'نشانی', 'خیابان', 'کوچه', 'مسیر', 'مبدأ', 'مبدا', 'مقصد', 'انبار'];
    }
    if (/(quantity|amount|count|number|volume)/i.test(key)) {
      return ['مقدار', 'تعداد', 'عدد', 'بسته', 'کیلو', 'گرم', 'تن', 'لیتر'];
    }
    if (/(person|people|actor|seller|buyer|victim|suspect)/i.test(key)) {
      return ['فرد', 'افراد', 'نفر', 'مرد', 'زن', 'فروشنده', 'خریدار', 'مظنون'];
    }
    if (/(weapon|arms|ammunition)/i.test(key)) {
      return ['سلاح', 'اسلحه', 'مهمات', 'فشنگ', 'کلت', 'تفنگ', 'چاقو'];
    }
    if (/(cause|reason|why|origin)/i.test(key)) {
      return ['علت', 'دلیل', 'منشأ', 'منشا', 'به دلیل', 'چون'];
    }
    if (/(damage|harm|impact|risk)/i.test(key)) {
      return ['خسارت', 'آسیب', 'مجروح', 'تخریب', 'خطر'];
    }
    if (/(method|action|activity|behavior|details|signs|evidence)/i.test(key)) {
      return ['نحوه', 'روش', 'اقدام', 'رفتار', 'نشانه', 'شواهد'];
    }
    if (/(type|kind|goods|items|material|subject)/i.test(key)) {
      return ['نوع', 'کالا', 'مال', 'مواد', 'سلاح', 'مهمات'];
    }
    return [];
  }

  function textAnswers(topic, sentences, text) {
    const answers = {};
    const usedSentences = new Set();
    topic.questions.forEach(question => {
      if (question.type === 'choices' || question.type === 'select') {
        const choice = selectedChoice(question.items, text);
        if (choice) answers[question.key] = choice;
        return;
      }
      const cues = questionCueTerms(question);
      if (!cues.length) return;
      const sentence = sentences.find(value => !usedSentences.has(value) && cues.some(cue => value.includes(cue)));
      // Never duplicate a whole narration sentence into unrelated questions. A
      // field receives a value only when its own cue is present; the remainder
      // stays blank for the reporter to complete during review.
      if (!sentence) return;
      answers[question.key] = sentence;
      usedSentences.add(sentence);
    });
    return answers;
  }

  function relatedAnswer(questions, sentences, text) {
    if (!questions.some(question => question.key === 'relatedPeople')) return {};
    const sentence = sentences.find(value => /همدست|با هم|چند نفر|باند|افراد مرتبط|همراه/.test(value));
    return sentence ? { relatedPeople: sentence } : {};
  }

  function sourceAnswer(questions, text) {
    if (!questions.some(question => question.key === 'sourceDescription')) return {};
    if (/خودم دیدم|شاهد بودم|با چشم خودم|جلوی چشمم/.test(text)) return { sourceDescription: 'مشاهده مستقیم' };
    if (/شنیدم|گفتند|به من گفتند|شنیده/.test(text)) return { sourceDescription: 'شنیده از دیگران' };
    if (/اطلاع قبلی|از قبل|خبر داشتم/.test(text)) return { sourceDescription: 'اطلاع قبلی' };
    return {};
  }

  function extractIncident(options) {
    const text = String(options && options.text || '').trim();
    const topics = Array.isArray(options && options.topics) ? options.topics : [];
    const relatedQuestions = Array.isArray(options && options.relatedQuestions) ? options.relatedQuestions : [];
    const sourceQuestions = Array.isArray(options && options.sourceQuestions) ? options.sourceQuestions : [];
    const result = { crimeTypes: {}, related: {}, source: {} };
    if (!text) return result;

    const selectedTopic = topics
      .map((topic, index) => ({ topic, index, score: topicScore(topic, text) }))
      .filter(candidate => candidate.score > 0)
      .sort((left, right) => right.score - left.score || left.index - right.index)[0];
    const sentences = splitSentences(text);
    if (selectedTopic) {
      const { topic } = selectedTopic;
      const answers = textAnswers(topic, sentences, text);
      // The recognized title itself is useful even when the narration does not
      // contain evidence for any individual field. Unmentioned questions stay
      // empty and are explicitly completed by the reporter during review.
      result.crimeTypes[topic.id] = { __label: topic.label, ...answers };
    }
    result.related = relatedAnswer(relatedQuestions, sentences, text);
    result.source = sourceAnswer(sourceQuestions, text);
    return result;
  }

  window.extractIncidentFromText = extractIncident;
})();
