/*
 * کاتالوگ عنوان‌های سناریو و پرسش‌های اختصاصی گزارش وقوع.
 * این فهرست در رابط کاربری نمایش داده نمی‌شود: دستیار صوتی/متنی از شرح کاربر
 * مناسب‌ترین عنوان را تشخیص می‌دهد و فقط پرسش‌های همان عنوان را باز می‌کند.
 * هر پرسش سناریویی الزامی است؛ بخش افراد مرتبط اختیاری و نحوه اطلاع الزامی می‌ماند.
 */
function scenarioText(key, label, type = 'textarea') {
  return Object.freeze({ key, label, type, required: true });
}

function scenarioChoices(key, label, items, options = {}) {
  return Object.freeze({
    key,
    label,
    type: options.select ? 'select' : 'choices',
    items: Object.freeze([...items]),
    columns: options.columns || 0,
    required: true
  });
}

let incidentScenarioSequence = 0;
function incidentTopic(label, questions, search = '') {
  incidentScenarioSequence += 1;
  return Object.freeze({
    id: `scenario-${incidentScenarioSequence}`,
    label,
    search: `${label} ${search}`.trim(),
    questions: Object.freeze([...questions])
  });
}

const DRUG_SCENARIO_FIELDS = Object.freeze([
  scenarioText('drugType', 'نوع مواد'),
  scenarioText('drugQuantity', 'مقدار مواد'),
  scenarioChoices('drugCultivatorProducer', 'آیا فرد مرتبط، کاشت یا تولید کننده است؟', ['بله', 'خیر', 'نامشخص'], { columns: 3 }),
  scenarioChoices('drugStudentInvolvement', 'دانش‌آموزان درگیر هستند؟', ['بله', 'خیر', 'نامشخص'], { columns: 3 }),
  scenarioText('drugTransit', 'مسیر، محل نگهداری یا جابه‌جایی')
]);

const INCIDENT_SCENARIOS = Object.freeze([
  incidentTopic('جرائم زیست محیطی', [
    scenarioText('environmentSubject', 'موضوع یا گونه در معرض آسیب'),
    scenarioText('environmentAction', 'آسیب یا اقدام مشاهده‌شده'),
    scenarioText('environmentLocation', 'محدوده یا محل وقوع')
  ]),
  incidentTopic('تعدی مامورین دولتی', [
    scenarioText('officialAbuseActor', 'مشخصات مأمور یا دستگاه مربوط'),
    scenarioText('officialAbuseAction', 'رفتار یا اقدام خارج از وظیفه'),
    scenarioText('officialAbuseImpact', 'اثر یا زیان ایجادشده')
  ]),
  incidentTopic('جرائم سایبری', [
    scenarioText('cyberService', 'سامانه، حساب یا بستر درگیر'),
    scenarioText('cyberConduct', 'رفتار یا اقدام مشاهده‌شده'),
    scenarioText('cyberImpact', 'آسیب یا هدف احتمالی')
  ]),
  incidentTopic('جرائم عمومی علیه اموال و اشخاص', [
    scenarioText('generalOffenceTarget', 'فرد یا مال درگیر'),
    scenarioText('generalOffenceAction', 'اقدام مشاهده‌شده'),
    scenarioText('generalOffenceImpact', 'خسارت یا آسیب واردشده')
  ]),
  incidentTopic('تیراندازی', [
    scenarioText('shootingLocation', 'محل تیراندازی'),
    scenarioText('shootingDirection', 'جهت و وضعیت تیراندازی'),
    scenarioText('shootingWeaponSigns', 'نوع سلاح یا نشانه‌های آن')
  ]),
  incidentTopic('بهره برداری غیرمجاز', [
    scenarioText('unauthorizedResource', 'منبع یا موضوع بهره‌برداری'),
    scenarioText('unauthorizedMethod', 'نحوه بهره‌برداری غیرمجاز'),
    scenarioText('unauthorizedLocation', 'محل یا محدوده')
  ]),
  incidentTopic('ادم ربایی', [
    scenarioText('abductionPerson', 'مشخصات فرد در معرض آدم‌ربایی'),
    scenarioText('abductionLastSeen', 'آخرین محل و زمان مشاهده'),
    scenarioText('abductionRelatedPeople', 'مشخصات یا نشانه‌های افراد مرتبط')
  ], 'آدم ربایی'),
  incidentTopic('پیدایش اجساد ناشناس', [
    scenarioText('unknownBodyLocation', 'محل پیدایش'),
    scenarioText('unknownBodyCondition', 'وضعیت ظاهری و شرایط محل'),
    scenarioText('unknownBodyIdentitySigns', 'نشانه‌های هویتی یا پوشش')
  ]),
  incidentTopic('حوادث و سوانح غیر عمدی', [
    scenarioText('accidentType', 'نوع حادثه یا سانحه'),
    scenarioText('accidentCause', 'علت احتمالی و روند وقوع'),
    scenarioText('accidentDamage', 'خسارت یا آسیب واردشده')
  ]),
  incidentTopic('امور امنیتی مجاز', [
    scenarioText('authorizedSecurityMatter', 'موضوع امنیتی مشاهده‌شده'),
    scenarioText('authorizedSecurityLocation', 'محل یا حوزه مربوط'),
    scenarioText('authorizedSecurityDetails', 'جزئیات مشاهده و دلیل اهمیت')
  ]),
  incidentTopic('امور خاص اتباع بیگانه_ دیپلمات', [
    scenarioText('foreignDiplomatPerson', 'مشخصات تبعه یا شخص دیپلماتیک'),
    scenarioText('foreignDiplomatConnection', 'ارتباط با موضوع'),
    scenarioText('foreignDiplomatPlace', 'محل یا مجموعه مرتبط')
  ], 'دیپلمات اتباع'),
  incidentTopic('مشاهدات وقایع مرزی', [
    scenarioText('borderEventLocation', 'نقطه یا محدوده مرزی'),
    scenarioText('borderEventDirection', 'جهت حرکت یا مسیر مشاهده‌شده'),
    scenarioText('borderEventPeople', 'افراد، وسیله یا نشانه‌های مرتبط')
  ]),
  incidentTopic('امور مالی و ملکی', [
    scenarioText('financialPropertySubject', 'موضوع مالی یا ملکی'),
    scenarioText('financialPropertyTransaction', 'معامله یا اقدام مشاهده‌شده'),
    scenarioText('financialPropertyImpact', 'زیان یا اختلاف ایجادشده')
  ]),
  incidentTopic('درگیری مسلحانه', [
    scenarioText('armedConflictLocation', 'محل درگیری'),
    scenarioText('armedConflictParties', 'افراد یا گروه‌های درگیر'),
    scenarioText('armedConflictWeaponSigns', 'سلاح یا نشانه‌های مشاهده‌شده')
  ]),
  incidentTopic('وقایع و فراخوان سایبری', [
    scenarioText('cyberCallPlatform', 'بستر یا کانال فراخوان'),
    scenarioText('cyberCallContent', 'محتوا یا پیام فراخوان'),
    scenarioText('cyberCallAudience', 'مخاطبان یا گروه هدف')
  ]),
  incidentTopic('حوادث مرتبط با با مواد محترقه غیر مجاز', [
    scenarioText('explosiveItemType', 'نوع ماده یا وسیله محترقه'),
    scenarioText('explosiveItemLocation', 'محل نگهداری یا وقوع'),
    scenarioText('explosiveItemRisk', 'خطر یا خسارت احتمالی')
  ], 'مواد محترقه غیرمجاز'),
  incidentTopic('جرائم علیه امنیت داخلی و خارجی', [
    scenarioText('securityThreatType', 'موضوع یا تهدید مشاهده‌شده'),
    scenarioText('securityThreatTarget', 'هدف یا محل مرتبط'),
    scenarioText('securityThreatEvidence', 'نشانه‌ها یا مستندات موجود')
  ]),
  incidentTopic('جرائم برخلاف تکالیف نظامی', [
    scenarioText('militaryDutyPerson', 'فرد یا واحد مرتبط'),
    scenarioText('militaryDutyBreach', 'تکلیف یا رفتار نقض‌شده'),
    scenarioText('militaryDutyLocation', 'محل یا زمان مرتبط')
  ]),
  incidentTopic('جرائم مرتبط با فرار', [
    scenarioText('escapePerson', 'مشخصات فرد مرتبط'),
    scenarioText('escapeStatus', 'وضعیت یا محل پیش از فرار'),
    scenarioText('escapeDirection', 'مسیر یا جهت احتمالی')
  ]),
  incidentTopic('جرائم علیه تمامیت اشخاص', [
    scenarioText('physicalIntegrityPerson', 'مشخصات فرد آسیب‌دیده یا در معرض آسیب'),
    scenarioText('physicalIntegrityAction', 'اقدام یا رفتار مشاهده‌شده'),
    scenarioText('physicalIntegrityInjury', 'آسیب یا نتیجه ایجادشده')
  ]),
  incidentTopic('جرائم علیه شخصیت معنوی و اشخاص و آزادی تن', [
    scenarioText('dignityPerson', 'فرد یا افراد درگیر'),
    scenarioText('dignityAction', 'رفتار یا اقدام مشاهده‌شده'),
    scenarioText('dignityEvidence', 'نشانه‌ها یا مستندات موجود')
  ]),
  incidentTopic('جرائم علیه اموال و مالکیت', [
    scenarioText('propertyOffenceTarget', 'مال یا حق مالکیت درگیر'),
    scenarioText('propertyOffenceAction', 'اقدام مشاهده‌شده'),
    scenarioText('propertyOffenceLoss', 'خسارت یا زیان واردشده')
  ]),
  incidentTopic('جرائم علیه نظم و آسایش عمومی', [
    scenarioText('publicOrderLocation', 'محل یا محدوده'),
    scenarioText('publicOrderBehavior', 'رفتار یا اقدام برهم‌زننده نظم'),
    scenarioText('publicOrderImpact', 'اثر آن بر مردم یا محیط')
  ]),
  incidentTopic('جرائم مرتبط با مواد مخدر_ قاچاق و تبانی', DRUG_SCENARIO_FIELDS, 'مواد مخدر قاچاق تبانی'),
  incidentTopic('جرائم ضد عفت و اخلاق عمومی', [
    scenarioText('moralityContext', 'محل یا بستر مرتبط'),
    scenarioText('moralityAction', 'رفتار یا اقدام مشاهده‌شده'),
    scenarioText('moralityPeople', 'افراد یا نشانه‌های مرتبط')
  ]),
  incidentTopic('جرائم مرتبط با رانندگی و وسایل نقلیه', [
    scenarioText('trafficVehicle', 'وسیله نقلیه یا راننده مرتبط'),
    scenarioText('trafficViolation', 'رفتار یا تخلف مشاهده‌شده'),
    scenarioText('trafficRisk', 'خطر یا خسارت ایجادشده')
  ]),
  incidentTopic('جرائم مرتبط با جعل و تزویر', [
    scenarioText('documentForgerySubject', 'مدرک، سند یا موضوع موردنظر'),
    scenarioText('documentForgerySigns', 'نشانه‌های جعل یا تزویر'),
    scenarioText('documentForgeryUse', 'محل یا نحوه استفاده مشاهده‌شده')
  ]),
  incidentTopic('جرائم مربوط به سوءاستفاده از شغل', [
    scenarioText('occupationalRole', 'شغل یا سمت مرتبط'),
    scenarioText('occupationalAbuse', 'نحوه سوءاستفاده مشاهده‌شده'),
    scenarioText('occupationalBenefit', 'منفعت یا زیان ایجادشده')
  ]),
  incidentTopic('جرائم مرتبط با ضابطین', [
    scenarioText('officerRelation', 'ضابط یا واحد مرتبط'),
    scenarioText('officerAction', 'اقدام یا رفتار مشاهده‌شده'),
    scenarioText('officerEvidence', 'نشانه‌ها یا مستندات موجود')
  ]),
  incidentTopic('جرائم رایانه ای', [
    scenarioText('computerService', 'سامانه، دستگاه یا حساب مرتبط'),
    scenarioText('computerAccess', 'روش یا وضعیت دسترسی مشاهده‌شده'),
    scenarioText('computerHarm', 'آسیب یا پیامد ایجادشده')
  ], 'رایانه‌ای'),
  incidentTopic('جرائم پزشکی و بهداشتی', [
    scenarioText('medicalSubject', 'خدمت، دارو یا موضوع پزشکی مرتبط'),
    scenarioText('medicalProvider', 'فرد یا مرکز ارائه‌دهنده'),
    scenarioText('medicalEffect', 'اثر یا خطر ایجادشده')
  ]),
  incidentTopic('فراخوان ها', [
    scenarioText('publicCallTopic', 'موضوع فراخوان'),
    scenarioText('publicCallChannel', 'راه یا بستر انتشار'),
    scenarioText('publicCallTime', 'زمان یا بازه اجرای فراخوان')
  ], 'فراخوان‌ها'),
  incidentTopic('تخلفات بهداشتی', [
    scenarioText('healthViolationPlace', 'محل یا واحد مرتبط'),
    scenarioText('healthViolationAction', 'تخلف بهداشتی مشاهده‌شده'),
    scenarioText('healthViolationRisk', 'خطر یا اثر احتمالی')
  ]),
  incidentTopic('اعتراض مسافرین', [
    scenarioText('passengerRoute', 'مسیر، پایانه یا وسیله مرتبط'),
    scenarioText('passengerReason', 'علت اعتراض مسافران'),
    scenarioText('passengerSituation', 'وضعیت فعلی و تعداد تقریبی افراد')
  ]),
  incidentTopic('مفاسد اجتماعی', [
    scenarioText('socialCorruptionPlace', 'محل یا بستر مرتبط'),
    scenarioText('socialCorruptionActivity', 'فعالیت یا رفتار مشاهده‌شده'),
    scenarioText('socialCorruptionImpact', 'اثر یا نگرانی ایجادشده')
  ]),
  incidentTopic('سرقت نزاع و درگیری', [
    scenarioText('theftTarget', 'مال یا محل در معرض سرقت'),
    scenarioText('theftOpportunityReason', 'به چه دلیل امکان سرقت وجود دارد'),
    scenarioText('theftConflictDetails', 'جزئیات نزاع یا درگیری مرتبط')
  ]),
  incidentTopic('شرارت', [
    scenarioText('disorderActor', 'مشخصات فرد یا افراد مرتبط'),
    scenarioText('disorderActions', 'اقدامات یا رفتار مشاهده‌شده'),
    scenarioText('disorderThreat', 'تهدید یا آسیب احتمالی')
  ]),
  incidentTopic('جعل و تقلب', [
    scenarioText('fraudSubject', 'کالا، سند یا موضوع مرتبط'),
    scenarioText('fraudSigns', 'نشانه‌های جعل یا تقلب'),
    scenarioText('fraudUse', 'محل یا نحوه استفاده مشاهده‌شده')
  ]),
  incidentTopic('غصب شغل و عناوین', [
    scenarioText('impersonationTitle', 'شغل، عنوان یا سمت مورد ادعا'),
    scenarioText('impersonationPerson', 'مشخصات فرد یا مجموعه مرتبط'),
    scenarioText('impersonationBenefit', 'منفعت یا اقدامی که با آن انجام شده')
  ]),
  incidentTopic('قاچاق', [
    scenarioText('traffickingGoods', 'کالا، شخص یا موضوع مورد قاچاق'),
    scenarioText('traffickingRoute', 'مبدأ، مقصد یا مسیر مرتبط'),
    scenarioChoices('traffickingIntent', 'قصد قاچاق', ['قاچاق اعضای بدن', 'جنسی', 'اتباع'], { select: true })
  ]),
  incidentTopic('مواد مخدر', DRUG_SCENARIO_FIELDS),
  incidentTopic('خودکشی', [
    scenarioText('selfHarmPerson', 'مشخصات فرد یا افراد مرتبط'),
    scenarioText('selfHarmStatus', 'وضعیت فعلی یا محل رخداد'),
    scenarioText('selfHarmSigns', 'نشانه‌ها یا دلایل احتمالی مشاهده‌شده')
  ]),
  incidentTopic('تهدید و اکراه', [
    scenarioText('threatTarget', 'فرد یا گروه مورد تهدید'),
    scenarioText('threatMethod', 'شیوه یا محتوای تهدید'),
    scenarioText('threatDemand', 'خواسته یا نتیجه موردنظر')
  ]),
  incidentTopic('حوادث و سوانح عمدی', [
    scenarioText('intentionalIncidentPlace', 'محل یا هدف حادثه'),
    scenarioText('intentionalIncidentAction', 'اقدام یا روند مشاهده‌شده'),
    scenarioText('intentionalIncidentDamage', 'خسارت یا آسیب ایجادشده')
  ]),
  incidentTopic('امور امنیتی و غیر‌مجاز', [
    scenarioText('unauthorizedSecurityMatter', 'موضوع امنیتی مشاهده‌شده'),
    scenarioText('unauthorizedSecurityLocation', 'محل یا حوزه مرتبط'),
    scenarioText('unauthorizedSecuritySigns', 'نشانه‌ها یا رفتار غیرمجاز')
  ], 'غیر مجاز'),
  incidentTopic('امور خاص اتباع بیگانه', [
    scenarioText('foreignPerson', 'مشخصات تبعه یا افراد مرتبط'),
    scenarioText('foreignStatus', 'وضعیت اقامت یا مدرک مرتبط'),
    scenarioText('foreignActivity', 'فعالیت یا محل مرتبط')
  ]),
  incidentTopic('جرائم مالی و اقتصادی', [
    scenarioText('financialEconomicSubject', 'موضوع مالی یا اقتصادی'),
    scenarioText('financialEconomicMethod', 'روش یا اقدام مشاهده‌شده'),
    scenarioText('financialEconomicAmount', 'مبلغ، حجم یا زیان احتمالی')
  ]),
  incidentTopic('جرائم و تخلفات راهور', [
    scenarioText('roadViolationVehicle', 'وسیله نقلیه یا راننده مرتبط'),
    scenarioText('roadViolationLocation', 'محل یا مسیر وقوع'),
    scenarioText('roadViolationRisk', 'خطر یا پیامد ایجادشده')
  ]),
  incidentTopic('تخلفات و جرائم صنفی', [
    scenarioText('businessUnit', 'واحد یا صنف مرتبط'),
    scenarioText('businessViolation', 'تخلف یا اقدام مشاهده‌شده'),
    scenarioText('businessAddress', 'نشانی یا محل فعالیت')
  ]),
  incidentTopic('جرائم ملکی', [
    scenarioText('realEstateSubject', 'ملک یا حق مورد اختلاف'),
    scenarioText('realEstateParties', 'افراد یا مجموعه‌های مرتبط'),
    scenarioText('realEstateClaim', 'اقدام، ادعا یا وضعیت مشاهده‌شده')
  ]),
  incidentTopic('اختلافات خانوادگی', [
    scenarioText('familyMembers', 'افراد خانواده یا وابستگان مرتبط'),
    scenarioText('familyDispute', 'موضوع اختلاف یا رفتار مشاهده‌شده'),
    scenarioText('familyRisk', 'خطر یا نیاز فوری احتمالی')
  ])
]);


const INCIDENT_TOPIC_QUESTIONS = Object.freeze({
  all: Object.freeze(INCIDENT_SCENARIOS)
});

const INCIDENT_RELATED_QUESTIONS = Object.freeze([
  { key: 'relatedPeople', type: 'textarea', label: 'همکاران و افراد مرتبط', optional: true }
]);

const INCIDENT_SOURCE_QUESTIONS = Object.freeze([
  { key: 'sourceDescription', type: 'textarea', label: 'نحوه اطلاع', required: true }
]);

if (typeof window !== 'undefined') {
  window.INCIDENT_TOPIC_QUESTIONS = INCIDENT_TOPIC_QUESTIONS;
  window.INCIDENT_RELATED_QUESTIONS = INCIDENT_RELATED_QUESTIONS;
  window.INCIDENT_SOURCE_QUESTIONS = INCIDENT_SOURCE_QUESTIONS;
}
