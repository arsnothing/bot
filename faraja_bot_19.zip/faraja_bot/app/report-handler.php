<?php
declare(strict_types=1);

// The 100 MiB allowance belongs to the entire document upload field, not each file.
const MAX_DOCUMENT_TOTAL_BYTES = 104857600;
const MAX_PROPERTY_PEOPLE = 10;

function jsonResponse(array $payload, int $status = 200): void {
  http_response_code($status);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  exit;
}

function clean($value) {
  if (is_string($value)) {
    $value = trim($value);
    return $value === '' ? null : $value;
  }
  return $value;
}

function englishDigits(string $value): string {
  return strtr($value, [
    '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
    '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
    '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
    '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9'
  ]);
}

function formValue(array $form, string $key): ?string {
  if (!array_key_exists($key, $form) || !is_scalar($form[$key])) return null;
  $value = trim((string)$form[$key]);
  return $value === '' ? null : $value;
}

function landlineAreaCodes(): array {
  // Every fixed-line number uses its provincial three-digit prefix followed by
  // an eight-digit subscriber number.
  return [
    'آذربایجان شرقی' => '041',
    'آذربایجان غربی' => '044',
    'اردبیل' => '045',
    'اصفهان' => '031',
    'البرز' => '026',
    'ایلام' => '084',
    'بوشهر' => '077',
    'تهران' => '021',
    'چهارمحال و بختیاری' => '038',
    'خراسان جنوبی' => '056',
    'خراسان رضوی' => '051',
    'خراسان شمالی' => '058',
    'خوزستان' => '061',
    'زنجان' => '024',
    'سمنان' => '023',
    'سیستان و بلوچستان' => '054',
    'فارس' => '071',
    'قزوین' => '028',
    'قم' => '025',
    'کردستان' => '087',
    'کرمان' => '034',
    'کرمانشاه' => '083',
    'کهگیلویه و بویراحمد' => '074',
    'گلستان' => '017',
    'گیلان' => '013',
    'لرستان' => '066',
    'مازندران' => '011',
    'مرکزی' => '086',
    'هرمزگان' => '076',
    'همدان' => '081',
    'یزد' => '035'
  ];
}

function normalizePeopleLandlineField(array &$form, string $field, string $provinceField, string $label): void {
  $areaCodes = landlineAreaCodes();
  if (array_key_exists($provinceField, $form) && !is_scalar($form[$provinceField])) {
    throw new InvalidArgumentException('استان ' . $label . ' نامعتبر است.');
  }
  $province = formValue($form, $provinceField);
  if ($province === null) unset($form[$provinceField]);
  elseif (!array_key_exists($province, $areaCodes)) {
    throw new InvalidArgumentException('استان ' . $label . ' نامعتبر است.');
  }

  if (array_key_exists($field, $form) && !is_scalar($form[$field])) {
    throw new InvalidArgumentException($label . ' نامعتبر است.');
  }
  $phone = formValue($form, $field);
  if ($phone === null) {
    unset($form[$field]);
    return;
  }

  $digits = englishDigits($phone);
  if (!preg_match('/^\d{8}$|^\d{11}$/', $digits)) {
    throw new InvalidArgumentException($label . ' باید شامل ۸ رقم شماره یا ۱۱ رقم کامل باشد.');
  }

  $inferredProvince = null;
  if (strlen($digits) === 11) {
    $prefix = substr($digits, 0, 3);
    foreach ($areaCodes as $candidateProvince => $candidatePrefix) {
      if ($candidatePrefix === $prefix) {
        $inferredProvince = $candidateProvince;
        break;
      }
    }
  }

  if ($province === null) $province = $inferredProvince;
  if ($province === null) {
    throw new InvalidArgumentException('برای ' . $label . ' استان را انتخاب کنید.');
  }

  // A province explicitly chosen in the UI always controls the persisted
  // prefix. This also upgrades old full numbers by inferring their province.
  $subscriber = strlen($digits) === 11 ? substr($digits, -8) : $digits;
  $form[$provinceField] = $province;
  $form[$field] = $areaCodes[$province] . $subscriber;
}

function normalizePeopleLandlines(array &$form, string $category): void {
  if ($category !== 'افراد') {
    unset($form['phoneFixedProvince'], $form['phoneWorkProvince']);
    return;
  }
  normalizePeopleLandlineField($form, 'phoneFixed', 'phoneFixedProvince', 'شماره ثابت محل سکونت');
  normalizePeopleLandlineField($form, 'phoneWork', 'phoneWorkProvince', 'شماره ثابت محل کار');
}

function validNationalId(string $value): bool {
  $digits = englishDigits($value);
  if (!preg_match('/^\d{10}$/', $digits) || preg_match('/^(\d)\1{9}$/', $digits)) return false;

  $sum = 0;
  for ($index = 0; $index < 9; $index++) {
    $sum += (int)$digits[$index] * (10 - $index);
  }
  $remainder = $sum % 11;
  $expected = $remainder < 2 ? $remainder : 11 - $remainder;
  return (int)$digits[9] === $expected;
}

function normalizeSocialLinks(array &$form): void {
  if (!array_key_exists('socialLinks', $form)) return;
  if (!is_array($form['socialLinks'])) {
    throw new InvalidArgumentException('نشانی‌های فضای مجازی نامعتبر است.');
  }
  if (count($form['socialLinks']) > 20) {
    throw new InvalidArgumentException('تعداد نشانی‌های فضای مجازی بیش از حد مجاز است.');
  }

  $platformPrefixes = [
    'telegram' => 't.me/',
    'instagram' => 'instagram.com/',
    'x' => 'x.com/',
    'whatsapp' => 'wa.me/',
    'youtube' => 'youtube.com/',
    'facebook' => 'facebook.com/',
    'linkedin' => 'linkedin.com/',
    'github' => 'github.com/',
    'tiktok' => 'tiktok.com/@',
    'threads' => 'threads.net/@',
    'discord' => 'discord.gg/',
    'eitaa' => 'eitaa.com/',
    'bale' => 'ble.ir/',
    'soroush' => 'splus.ir/',
    'rubika' => 'rubika.ir/',
    'igap' => 'igap.net/',
    'gap' => 'gap.im/',
    'virasty' => 'virasty.com/',
    'aparat' => 'aparat.com/'
  ];

  $links = [];
  foreach ($form['socialLinks'] as $link) {
    if (!is_array($link)) continue;
    $platform = isset($link['platform']) && is_string($link['platform']) ? trim($link['platform']) : '';
    $value = isset($link['value']) && is_string($link['value']) ? trim($link['value']) : '';
    if ($platform === '' && $value === '') continue;
    if (!array_key_exists($platform, $platformPrefixes)) {
      throw new InvalidArgumentException('پلتفرم انتخاب‌شده نامعتبر است.');
    }
    // ردیف‌های انتخاب‌شده اما ناتمام در رابط کاربری، در گزارش نهایی ذخیره نمی‌شوند.
    if ($value === '') continue;
    if (strlen($value) > 500 || preg_match('/[\x00-\x1F]/', $value)) {
      throw new InvalidArgumentException('نشانی فضای مجازی نامعتبر است.');
    }
    $value = ltrim($value, '/');
    if ($value === '') continue;
    $links[] = [
      'platform' => $platform,
      'value' => $value,
      'url' => 'https://' . $platformPrefixes[$platform] . $value
    ];
  }

  if ($links) $form['socialLinks'] = $links;
  else unset($form['socialLinks']);
}

function vehiclesHaveMeaningfulValue(array $vehicles): bool {
  foreach ($vehicles as $vehicle) {
    if (!is_array($vehicle)) continue;
    foreach (['kind', 'type', 'color', 'specialFeature'] as $key) {
      if (isset($vehicle[$key]) && is_scalar($vehicle[$key]) && trim((string)$vehicle[$key]) !== '') return true;
    }
    if (!empty($vehicle['noPlate'])) return true;
    if (isset($vehicle['plate']) && is_array($vehicle['plate']) && !empty($vehicle['plate']['template'])) return true;
  }
  return false;
}

function propertyPeopleHaveMeaningfulValue(array $people): bool {
  foreach (['owner', 'resident', 'visitor'] as $role) {
    $entries = $people[$role] ?? [];
    if (!is_array($entries)) continue;
    foreach ($entries as $person) {
      if (!is_array($person)) continue;
      foreach ($person as $value) {
        if ($value === true || (is_scalar($value) && trim((string)$value) !== '')) return true;
      }
    }
  }
  return false;
}

function formHasMeaningfulValue(array $form): bool {
  foreach ($form as $key => $value) {
    // Province selection is auxiliary UI state. By itself it is not report data.
    if (in_array($key, ['phoneFixedProvince', 'phoneWorkProvince'], true)) continue;
    if (is_scalar($value) && trim((string)$value) !== '') return true;
    if ($key === 'socialLinks' && is_array($value) && count($value) > 0) return true;
    if ($key === 'vehiclePlate' && is_array($value) && !empty($value['template'])) return true;
    if ($key === 'vehicles' && is_array($value) && vehiclesHaveMeaningfulValue($value)) return true;
    if ($key === 'propertyPeople' && is_array($value) && propertyPeopleHaveMeaningfulValue($value)) return true;
    if ($key === 'incident' && is_array($value) && incidentHasMeaningfulValue($value)) return true;
  }
  return false;
}

function incidentHasMeaningfulValue(array $incident): bool {
  foreach (['crimeTypes', 'related', 'source'] as $group) {
    if (!isset($incident[$group]) || !is_array($incident[$group])) continue;
    foreach ($incident[$group] as $entry) {
      if (is_scalar($entry) && trim((string)$entry) !== '') return true;
      if (is_array($entry)) {
        foreach ($entry as $answer) {
          if (is_scalar($answer) && trim((string)$answer) !== '') return true;
        }
      }
    }
  }
  return false;
}

function propertyPersonRoleLabels(): array {
  return [
    'owner' => 'مالک',
    'resident' => 'ساکن',
    'visitor' => 'ترددکننده'
  ];
}

function propertyPersonLegacyKeys(): array {
  $suffixes = ['FirstName', 'LastName', 'Nickname', 'Phone', 'Gender', 'Height', 'BodyBuild', 'Face', 'HairColor', 'HairStatus', 'Beard', 'Appearance'];
  $keys = [];
  foreach (array_keys(propertyPersonRoleLabels()) as $role) {
    foreach ($suffixes as $suffix) $keys[] = $role . $suffix;
  }
  $keys[] = 'ownerIsResident';
  $keys[] = 'ownerIsVisitor';
  return $keys;
}

function normalizePropertyPeople(array &$form): void {
  // Flat role fields belonged to the preceding property design. The browser
  // migrates a saved draft, but manual legacy payloads intentionally do not stay.
  foreach (propertyPersonLegacyKeys() as $key) unset($form[$key]);
  if (!array_key_exists('propertyPeople', $form)) return;
  if (!is_array($form['propertyPeople'])) {
    throw new InvalidArgumentException('بسته‌های مشخصات افراد مرتبط با ملک نامعتبر است.');
  }

  $allowedFields = ['firstName', 'lastName', 'nickname', 'phone', 'gender', 'height', 'bodyBuild', 'face', 'hairColor', 'hairStatus', 'beard', 'appearance'];
  $normalizedPeople = [];
  foreach (propertyPersonRoleLabels() as $role => $label) {
    $entries = $form['propertyPeople'][$role] ?? [];
    if (!is_array($entries)) {
      throw new InvalidArgumentException('بسته‌های مشخصات ' . $label . ' نامعتبر است.');
    }
    if (count($entries) > MAX_PROPERTY_PEOPLE) {
      throw new InvalidArgumentException('تعداد بسته‌های مشخصات ' . $label . ' بیش از حد مجاز است.');
    }

    $normalizedPeople[$role] = [];
    foreach ($entries as $person) {
      if (!is_array($person)) {
        throw new InvalidArgumentException('بسته مشخصات ' . $label . ' نامعتبر است.');
      }
      $normalized = [];
      foreach ($allowedFields as $field) {
        if (!array_key_exists($field, $person)) continue;
        if (!is_scalar($person[$field])) {
          throw new InvalidArgumentException('مقدار مشخصات ' . $label . ' نامعتبر است.');
        }
        $value = trim((string)$person[$field]);
        if ($value !== '') $normalized[$field] = $value;
      }
      if ($role === 'owner') {
        foreach (['isResident', 'isVisitor'] as $flag) {
          if (!array_key_exists($flag, $person)) continue;
          if ($person[$flag] !== true) {
            throw new InvalidArgumentException('وضعیت مالک نسبت به ملک نامعتبر است.');
          }
          $normalized[$flag] = true;
        }
      }
      $normalizedPeople[$role][] = $normalized;
    }
  }
  $form['propertyPeople'] = $normalizedPeople;
}

function validatePropertyPersonFields(array $form): void {
  $people = $form['propertyPeople'] ?? [];
  if (!is_array($people)) return;

  foreach (propertyPersonRoleLabels() as $role => $label) {
    $entries = $people[$role] ?? [];
    if (!is_array($entries)) continue;
    foreach ($entries as $person) {
      if (!is_array($person)) continue;
      $phone = formValue($person, 'phone');
      if ($phone !== null && !preg_match('/^\d{11}$/', englishDigits($phone))) {
        throw new InvalidArgumentException('شماره تماس ' . $label . ' باید دقیقاً ۱۱ رقم باشد.');
      }

      $height = formValue($person, 'height');
      if ($height !== null) {
        $digits = englishDigits($height);
        if (!preg_match('/^\d{1,3}$/', $digits) || (int)$digits < 1 || (int)$digits > 250) {
          throw new InvalidArgumentException('قد ' . $label . ' باید عددی تا ۳ رقم و حداکثر ۲۵۰ باشد.');
        }
      }

      $gender = formValue($person, 'gender');
      if ($gender !== null && !in_array($gender, ['مرد', 'زن', 'نامشخص'], true)) {
        throw new InvalidArgumentException('جنسیت ' . $label . ' باید مرد، زن یا نامشخص باشد.');
      }

      $bodyBuild = formValue($person, 'bodyBuild');
      if ($bodyBuild !== null && !in_array($bodyBuild, ['لاغر', 'معمولی', 'چاق'], true)) {
        throw new InvalidArgumentException('اندام ' . $label . ' نامعتبر است.');
      }

      foreach (['firstName' => 'نام', 'lastName' => 'نام خانوادگی', 'nickname' => 'شهرت', 'face' => 'رنگ پوست', 'hairStatus' => 'وضعیت موی سر', 'hairColor' => 'رنگ مو', 'beard' => 'محاسن'] as $field => $fieldLabel) {
        $value = formValue($person, $field);
        if ($value !== null && preg_match('/[0-9۰-۹٠-٩]/u', $value)) {
          throw new InvalidArgumentException($fieldLabel . ' ' . $label . ' فقط باید شامل متن باشد.');
        }
      }
    }
  }
}

function normalizePropertyFields(array &$form): void {
  // Fields from the retired, single-text property form must not survive drafts or
  // manual submissions. Structured vehicle and repeatable person packages remain.
  unset($form['propertyAddress'], $form['owners'], $form['activity']);
  normalizePropertyPeople($form);
  if (array_key_exists('vehicles', $form) && !is_array($form['vehicles'])) unset($form['vehicles']);
}

function normalizeLocationDetailFields(array &$location): void {
  // The one-box address field was replaced everywhere by four explicit fields.
  unset($location['address']);
  foreach (['postalCode', 'buildingPlaque', 'floor', 'unit'] as $key) {
    if (!array_key_exists($key, $location)) continue;
    if (!is_scalar($location[$key])) {
      throw new InvalidArgumentException('جزئیات مکان وقوع نامعتبر است.');
    }
    $value = trim((string)$location[$key]);
    if ($value === '') unset($location[$key]);
    else $location[$key] = $value;
  }

  $mode = isset($location['mode']) && is_scalar($location['mode']) ? trim((string)$location['mode']) : '';
  if ($mode === 'unknown') {
    unset($location['postalCode'], $location['buildingPlaque'], $location['floor'], $location['unit']);
  }
}

function normalizePropertyLocation(array &$location): void {
  $mode = isset($location['mode']) && is_scalar($location['mode']) ? trim((string)$location['mode']) : '';
  if ($mode === 'unknown') {
    throw new InvalidArgumentException('برای گزارش املاک، مکان وقوع را از طریق موقعیت فعلی یا نقشه تعیین کنید.');
  }
  // Province/county controls only belong to the unknown-location flow, which is
  // intentionally unavailable for property reports.
  unset($location['province'], $location['city']);
}

function validateFormFields(array $form, ?string $category = null): void {
  $nationalId = formValue($form, 'nationalId');
  if ($nationalId !== null && !validNationalId($nationalId)) {
    throw new InvalidArgumentException('کد ملی باید ۱۰ رقم معتبر باشد.');
  }

  foreach (['phoneFixed' => 'شماره ثابت محل سکونت', 'phoneMobile' => 'شماره همراه', 'phoneWork' => 'شماره ثابت محل کار', 'phoneHome' => 'شماره ثابت محل سکونت'] as $key => $label) {
    $phone = formValue($form, $key);
    if ($phone !== null && !preg_match('/^\d{11}$/', englishDigits($phone))) {
      throw new InvalidArgumentException($label . ' باید دقیقاً ۱۱ رقم باشد.');
    }
  }

  $age = formValue($form, 'age');
  if ($age !== null) {
    $digits = englishDigits($age);
    if (!preg_match('/^\d{1,3}$/', $digits) || (int)$digits < 1 || (int)$digits > 120) {
      throw new InvalidArgumentException('سن باید عددی بین ۱ تا ۱۲۰ باشد.');
    }
  }

  $height = formValue($form, 'height');
  if ($height !== null) {
    $digits = englishDigits($height);
    if (!preg_match('/^\d{1,3}$/', $digits) || (int)$digits < 1 || (int)$digits > 250) {
      throw new InvalidArgumentException('قد باید عددی تا ۳ رقم و حداکثر ۲۵۰ باشد.');
    }
  }

  $email = formValue($form, 'email');
  if ($email !== null && filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
    throw new InvalidArgumentException('نشانی پست الکترونیک را به شکل یک ایمیل معتبر وارد کنید.');
  }

  $gender = formValue($form, 'gender');
  if ($gender !== null && !in_array($gender, ['مرد', 'زن', 'نامشخص'], true)) {
    throw new InvalidArgumentException('جنسیت باید مرد، زن یا نامشخص باشد.');
  }

  $bodyBuild = formValue($form, 'bodyBuild');
  if ($bodyBuild !== null && !in_array($bodyBuild, ['لاغر', 'معمولی', 'چاق'], true)) {
    throw new InvalidArgumentException('اندام انتخاب‌شده نامعتبر است.');
  }

  foreach (['firstName' => 'نام', 'lastName' => 'نام خانوادگی', 'nickname' => 'شهرت', 'face' => 'رنگ پوست', 'hairStatus' => 'وضعیت موی سر', 'hairColor' => 'رنگ مو', 'beard' => 'محاسن'] as $key => $label) {
    $value = formValue($form, $key);
    if ($value !== null && preg_match('/[0-9۰-۹٠-٩]/u', $value)) {
      throw new InvalidArgumentException($label . ' فقط باید شامل متن باشد.');
    }
  }

  if ($category === 'املاک') validatePropertyPersonFields($form);
}

function incidentScenarioDefinitions(): array {
  static $definitions = null;
  if ($definitions !== null) return $definitions;
  $definitions = [
    'scenario-1' => [
      'label' => 'جرائم زیست محیطی',
      'fields' => [
        'environmentSubject' => ['label' => 'موضوع یا گونه در معرض آسیب', 'type' => 'textarea'],
        'environmentAction' => ['label' => 'آسیب یا اقدام مشاهده‌شده', 'type' => 'textarea'],
        'environmentLocation' => ['label' => 'محدوده یا محل وقوع', 'type' => 'textarea'],
      ]
    ],
    'scenario-2' => [
      'label' => 'تعدی مامورین دولتی',
      'fields' => [
        'officialAbuseActor' => ['label' => 'مشخصات مأمور یا دستگاه مربوط', 'type' => 'textarea'],
        'officialAbuseAction' => ['label' => 'رفتار یا اقدام خارج از وظیفه', 'type' => 'textarea'],
        'officialAbuseImpact' => ['label' => 'اثر یا زیان ایجادشده', 'type' => 'textarea'],
      ]
    ],
    'scenario-3' => [
      'label' => 'جرائم سایبری',
      'fields' => [
        'cyberService' => ['label' => 'سامانه، حساب یا بستر درگیر', 'type' => 'textarea'],
        'cyberConduct' => ['label' => 'رفتار یا اقدام مشاهده‌شده', 'type' => 'textarea'],
        'cyberImpact' => ['label' => 'آسیب یا هدف احتمالی', 'type' => 'textarea'],
      ]
    ],
    'scenario-4' => [
      'label' => 'جرائم عمومی علیه اموال و اشخاص',
      'fields' => [
        'generalOffenceTarget' => ['label' => 'فرد یا مال درگیر', 'type' => 'textarea'],
        'generalOffenceAction' => ['label' => 'اقدام مشاهده‌شده', 'type' => 'textarea'],
        'generalOffenceImpact' => ['label' => 'خسارت یا آسیب واردشده', 'type' => 'textarea'],
      ]
    ],
    'scenario-5' => [
      'label' => 'تیراندازی',
      'fields' => [
        'shootingLocation' => ['label' => 'محل تیراندازی', 'type' => 'textarea'],
        'shootingDirection' => ['label' => 'جهت و وضعیت تیراندازی', 'type' => 'textarea'],
        'shootingWeaponSigns' => ['label' => 'نوع سلاح یا نشانه‌های آن', 'type' => 'textarea'],
      ]
    ],
    'scenario-6' => [
      'label' => 'بهره برداری غیرمجاز',
      'fields' => [
        'unauthorizedResource' => ['label' => 'منبع یا موضوع بهره‌برداری', 'type' => 'textarea'],
        'unauthorizedMethod' => ['label' => 'نحوه بهره‌برداری غیرمجاز', 'type' => 'textarea'],
        'unauthorizedLocation' => ['label' => 'محل یا محدوده', 'type' => 'textarea'],
      ]
    ],
    'scenario-7' => [
      'label' => 'ادم ربایی',
      'fields' => [
        'abductionPerson' => ['label' => 'مشخصات فرد در معرض آدم‌ربایی', 'type' => 'textarea'],
        'abductionLastSeen' => ['label' => 'آخرین محل و زمان مشاهده', 'type' => 'textarea'],
        'abductionRelatedPeople' => ['label' => 'مشخصات یا نشانه‌های افراد مرتبط', 'type' => 'textarea'],
      ]
    ],
    'scenario-8' => [
      'label' => 'پیدایش اجساد ناشناس',
      'fields' => [
        'unknownBodyLocation' => ['label' => 'محل پیدایش', 'type' => 'textarea'],
        'unknownBodyCondition' => ['label' => 'وضعیت ظاهری و شرایط محل', 'type' => 'textarea'],
        'unknownBodyIdentitySigns' => ['label' => 'نشانه‌های هویتی یا پوشش', 'type' => 'textarea'],
      ]
    ],
    'scenario-9' => [
      'label' => 'حوادث و سوانح غیر عمدی',
      'fields' => [
        'accidentType' => ['label' => 'نوع حادثه یا سانحه', 'type' => 'textarea'],
        'accidentCause' => ['label' => 'علت احتمالی و روند وقوع', 'type' => 'textarea'],
        'accidentDamage' => ['label' => 'خسارت یا آسیب واردشده', 'type' => 'textarea'],
      ]
    ],
    'scenario-10' => [
      'label' => 'امور امنیتی مجاز',
      'fields' => [
        'authorizedSecurityMatter' => ['label' => 'موضوع امنیتی مشاهده‌شده', 'type' => 'textarea'],
        'authorizedSecurityLocation' => ['label' => 'محل یا حوزه مربوط', 'type' => 'textarea'],
        'authorizedSecurityDetails' => ['label' => 'جزئیات مشاهده و دلیل اهمیت', 'type' => 'textarea'],
      ]
    ],
    'scenario-11' => [
      'label' => 'امور خاص اتباع بیگانه_ دیپلمات',
      'fields' => [
        'foreignDiplomatPerson' => ['label' => 'مشخصات تبعه یا شخص دیپلماتیک', 'type' => 'textarea'],
        'foreignDiplomatConnection' => ['label' => 'ارتباط با موضوع', 'type' => 'textarea'],
        'foreignDiplomatPlace' => ['label' => 'محل یا مجموعه مرتبط', 'type' => 'textarea'],
      ]
    ],
    'scenario-12' => [
      'label' => 'مشاهدات وقایع مرزی',
      'fields' => [
        'borderEventLocation' => ['label' => 'نقطه یا محدوده مرزی', 'type' => 'textarea'],
        'borderEventDirection' => ['label' => 'جهت حرکت یا مسیر مشاهده‌شده', 'type' => 'textarea'],
        'borderEventPeople' => ['label' => 'افراد، وسیله یا نشانه‌های مرتبط', 'type' => 'textarea'],
      ]
    ],
    'scenario-13' => [
      'label' => 'امور مالی و ملکی',
      'fields' => [
        'financialPropertySubject' => ['label' => 'موضوع مالی یا ملکی', 'type' => 'textarea'],
        'financialPropertyTransaction' => ['label' => 'معامله یا اقدام مشاهده‌شده', 'type' => 'textarea'],
        'financialPropertyImpact' => ['label' => 'زیان یا اختلاف ایجادشده', 'type' => 'textarea'],
      ]
    ],
    'scenario-14' => [
      'label' => 'درگیری مسلحانه',
      'fields' => [
        'armedConflictLocation' => ['label' => 'محل درگیری', 'type' => 'textarea'],
        'armedConflictParties' => ['label' => 'افراد یا گروه‌های درگیر', 'type' => 'textarea'],
        'armedConflictWeaponSigns' => ['label' => 'سلاح یا نشانه‌های مشاهده‌شده', 'type' => 'textarea'],
      ]
    ],
    'scenario-15' => [
      'label' => 'وقایع و فراخوان سایبری',
      'fields' => [
        'cyberCallPlatform' => ['label' => 'بستر یا کانال فراخوان', 'type' => 'textarea'],
        'cyberCallContent' => ['label' => 'محتوا یا پیام فراخوان', 'type' => 'textarea'],
        'cyberCallAudience' => ['label' => 'مخاطبان یا گروه هدف', 'type' => 'textarea'],
      ]
    ],
    'scenario-16' => [
      'label' => 'حوادث مرتبط با با مواد محترقه غیر مجاز',
      'fields' => [
        'explosiveItemType' => ['label' => 'نوع ماده یا وسیله محترقه', 'type' => 'textarea'],
        'explosiveItemLocation' => ['label' => 'محل نگهداری یا وقوع', 'type' => 'textarea'],
        'explosiveItemRisk' => ['label' => 'خطر یا خسارت احتمالی', 'type' => 'textarea'],
      ]
    ],
    'scenario-17' => [
      'label' => 'جرائم علیه امنیت داخلی و خارجی',
      'fields' => [
        'securityThreatType' => ['label' => 'موضوع یا تهدید مشاهده‌شده', 'type' => 'textarea'],
        'securityThreatTarget' => ['label' => 'هدف یا محل مرتبط', 'type' => 'textarea'],
        'securityThreatEvidence' => ['label' => 'نشانه‌ها یا مستندات موجود', 'type' => 'textarea'],
      ]
    ],
    'scenario-18' => [
      'label' => 'جرائم برخلاف تکالیف نظامی',
      'fields' => [
        'militaryDutyPerson' => ['label' => 'فرد یا واحد مرتبط', 'type' => 'textarea'],
        'militaryDutyBreach' => ['label' => 'تکلیف یا رفتار نقض‌شده', 'type' => 'textarea'],
        'militaryDutyLocation' => ['label' => 'محل یا زمان مرتبط', 'type' => 'textarea'],
      ]
    ],
    'scenario-19' => [
      'label' => 'جرائم مرتبط با فرار',
      'fields' => [
        'escapePerson' => ['label' => 'مشخصات فرد مرتبط', 'type' => 'textarea'],
        'escapeStatus' => ['label' => 'وضعیت یا محل پیش از فرار', 'type' => 'textarea'],
        'escapeDirection' => ['label' => 'مسیر یا جهت احتمالی', 'type' => 'textarea'],
      ]
    ],
    'scenario-20' => [
      'label' => 'جرائم علیه تمامیت اشخاص',
      'fields' => [
        'physicalIntegrityPerson' => ['label' => 'مشخصات فرد آسیب‌دیده یا در معرض آسیب', 'type' => 'textarea'],
        'physicalIntegrityAction' => ['label' => 'اقدام یا رفتار مشاهده‌شده', 'type' => 'textarea'],
        'physicalIntegrityInjury' => ['label' => 'آسیب یا نتیجه ایجادشده', 'type' => 'textarea'],
      ]
    ],
    'scenario-21' => [
      'label' => 'جرائم علیه شخصیت معنوی و اشخاص و آزادی تن',
      'fields' => [
        'dignityPerson' => ['label' => 'فرد یا افراد درگیر', 'type' => 'textarea'],
        'dignityAction' => ['label' => 'رفتار یا اقدام مشاهده‌شده', 'type' => 'textarea'],
        'dignityEvidence' => ['label' => 'نشانه‌ها یا مستندات موجود', 'type' => 'textarea'],
      ]
    ],
    'scenario-22' => [
      'label' => 'جرائم علیه اموال و مالکیت',
      'fields' => [
        'propertyOffenceTarget' => ['label' => 'مال یا حق مالکیت درگیر', 'type' => 'textarea'],
        'propertyOffenceAction' => ['label' => 'اقدام مشاهده‌شده', 'type' => 'textarea'],
        'propertyOffenceLoss' => ['label' => 'خسارت یا زیان واردشده', 'type' => 'textarea'],
      ]
    ],
    'scenario-23' => [
      'label' => 'جرائم علیه نظم و آسایش عمومی',
      'fields' => [
        'publicOrderLocation' => ['label' => 'محل یا محدوده', 'type' => 'textarea'],
        'publicOrderBehavior' => ['label' => 'رفتار یا اقدام برهم‌زننده نظم', 'type' => 'textarea'],
        'publicOrderImpact' => ['label' => 'اثر آن بر مردم یا محیط', 'type' => 'textarea'],
      ]
    ],
    'scenario-24' => [
      'label' => 'جرائم مرتبط با مواد مخدر_ قاچاق و تبانی',
      'fields' => [
        'drugType' => ['label' => 'نوع مواد', 'type' => 'textarea'],
        'drugQuantity' => ['label' => 'مقدار مواد', 'type' => 'textarea'],
        'drugCultivatorProducer' => ['label' => 'آیا فرد مرتبط، کاشت یا تولید کننده است؟', 'type' => 'choices', 'items' => ['بله', 'خیر', 'نامشخص']],
        'drugStudentInvolvement' => ['label' => 'دانش‌آموزان درگیر هستند؟', 'type' => 'choices', 'items' => ['بله', 'خیر', 'نامشخص']],
        'drugTransit' => ['label' => 'مسیر، محل نگهداری یا جابه‌جایی', 'type' => 'textarea'],
      ]
    ],
    'scenario-25' => [
      'label' => 'جرائم ضد عفت و اخلاق عمومی',
      'fields' => [
        'moralityContext' => ['label' => 'محل یا بستر مرتبط', 'type' => 'textarea'],
        'moralityAction' => ['label' => 'رفتار یا اقدام مشاهده‌شده', 'type' => 'textarea'],
        'moralityPeople' => ['label' => 'افراد یا نشانه‌های مرتبط', 'type' => 'textarea'],
      ]
    ],
    'scenario-26' => [
      'label' => 'جرائم مرتبط با رانندگی و وسایل نقلیه',
      'fields' => [
        'trafficVehicle' => ['label' => 'وسیله نقلیه یا راننده مرتبط', 'type' => 'textarea'],
        'trafficViolation' => ['label' => 'رفتار یا تخلف مشاهده‌شده', 'type' => 'textarea'],
        'trafficRisk' => ['label' => 'خطر یا خسارت ایجادشده', 'type' => 'textarea'],
      ]
    ],
    'scenario-27' => [
      'label' => 'جرائم مرتبط با جعل و تزویر',
      'fields' => [
        'documentForgerySubject' => ['label' => 'مدرک، سند یا موضوع موردنظر', 'type' => 'textarea'],
        'documentForgerySigns' => ['label' => 'نشانه‌های جعل یا تزویر', 'type' => 'textarea'],
        'documentForgeryUse' => ['label' => 'محل یا نحوه استفاده مشاهده‌شده', 'type' => 'textarea'],
      ]
    ],
    'scenario-28' => [
      'label' => 'جرائم مربوط به سوءاستفاده از شغل',
      'fields' => [
        'occupationalRole' => ['label' => 'شغل یا سمت مرتبط', 'type' => 'textarea'],
        'occupationalAbuse' => ['label' => 'نحوه سوءاستفاده مشاهده‌شده', 'type' => 'textarea'],
        'occupationalBenefit' => ['label' => 'منفعت یا زیان ایجادشده', 'type' => 'textarea'],
      ]
    ],
    'scenario-29' => [
      'label' => 'جرائم مرتبط با ضابطین',
      'fields' => [
        'officerRelation' => ['label' => 'ضابط یا واحد مرتبط', 'type' => 'textarea'],
        'officerAction' => ['label' => 'اقدام یا رفتار مشاهده‌شده', 'type' => 'textarea'],
        'officerEvidence' => ['label' => 'نشانه‌ها یا مستندات موجود', 'type' => 'textarea'],
      ]
    ],
    'scenario-30' => [
      'label' => 'جرائم رایانه ای',
      'fields' => [
        'computerService' => ['label' => 'سامانه، دستگاه یا حساب مرتبط', 'type' => 'textarea'],
        'computerAccess' => ['label' => 'روش یا وضعیت دسترسی مشاهده‌شده', 'type' => 'textarea'],
        'computerHarm' => ['label' => 'آسیب یا پیامد ایجادشده', 'type' => 'textarea'],
      ]
    ],
    'scenario-31' => [
      'label' => 'جرائم پزشکی و بهداشتی',
      'fields' => [
        'medicalSubject' => ['label' => 'خدمت، دارو یا موضوع پزشکی مرتبط', 'type' => 'textarea'],
        'medicalProvider' => ['label' => 'فرد یا مرکز ارائه‌دهنده', 'type' => 'textarea'],
        'medicalEffect' => ['label' => 'اثر یا خطر ایجادشده', 'type' => 'textarea'],
      ]
    ],
    'scenario-32' => [
      'label' => 'فراخوان ها',
      'fields' => [
        'publicCallTopic' => ['label' => 'موضوع فراخوان', 'type' => 'textarea'],
        'publicCallChannel' => ['label' => 'راه یا بستر انتشار', 'type' => 'textarea'],
        'publicCallTime' => ['label' => 'زمان یا بازه اجرای فراخوان', 'type' => 'textarea'],
      ]
    ],
    'scenario-33' => [
      'label' => 'تخلفات بهداشتی',
      'fields' => [
        'healthViolationPlace' => ['label' => 'محل یا واحد مرتبط', 'type' => 'textarea'],
        'healthViolationAction' => ['label' => 'تخلف بهداشتی مشاهده‌شده', 'type' => 'textarea'],
        'healthViolationRisk' => ['label' => 'خطر یا اثر احتمالی', 'type' => 'textarea'],
      ]
    ],
    'scenario-34' => [
      'label' => 'اعتراض مسافرین',
      'fields' => [
        'passengerRoute' => ['label' => 'مسیر، پایانه یا وسیله مرتبط', 'type' => 'textarea'],
        'passengerReason' => ['label' => 'علت اعتراض مسافران', 'type' => 'textarea'],
        'passengerSituation' => ['label' => 'وضعیت فعلی و تعداد تقریبی افراد', 'type' => 'textarea'],
      ]
    ],
    'scenario-35' => [
      'label' => 'مفاسد اجتماعی',
      'fields' => [
        'socialCorruptionPlace' => ['label' => 'محل یا بستر مرتبط', 'type' => 'textarea'],
        'socialCorruptionActivity' => ['label' => 'فعالیت یا رفتار مشاهده‌شده', 'type' => 'textarea'],
        'socialCorruptionImpact' => ['label' => 'اثر یا نگرانی ایجادشده', 'type' => 'textarea'],
      ]
    ],
    'scenario-36' => [
      'label' => 'سرقت نزاع و درگیری',
      'fields' => [
        'theftTarget' => ['label' => 'مال یا محل در معرض سرقت', 'type' => 'textarea'],
        'theftOpportunityReason' => ['label' => 'به چه دلیل امکان سرقت وجود دارد', 'type' => 'textarea'],
        'theftConflictDetails' => ['label' => 'جزئیات نزاع یا درگیری مرتبط', 'type' => 'textarea'],
      ]
    ],
    'scenario-37' => [
      'label' => 'شرارت',
      'fields' => [
        'disorderActor' => ['label' => 'مشخصات فرد یا افراد مرتبط', 'type' => 'textarea'],
        'disorderActions' => ['label' => 'اقدامات یا رفتار مشاهده‌شده', 'type' => 'textarea'],
        'disorderThreat' => ['label' => 'تهدید یا آسیب احتمالی', 'type' => 'textarea'],
      ]
    ],
    'scenario-38' => [
      'label' => 'جعل و تقلب',
      'fields' => [
        'fraudSubject' => ['label' => 'کالا، سند یا موضوع مرتبط', 'type' => 'textarea'],
        'fraudSigns' => ['label' => 'نشانه‌های جعل یا تقلب', 'type' => 'textarea'],
        'fraudUse' => ['label' => 'محل یا نحوه استفاده مشاهده‌شده', 'type' => 'textarea'],
      ]
    ],
    'scenario-39' => [
      'label' => 'غصب شغل و عناوین',
      'fields' => [
        'impersonationTitle' => ['label' => 'شغل، عنوان یا سمت مورد ادعا', 'type' => 'textarea'],
        'impersonationPerson' => ['label' => 'مشخصات فرد یا مجموعه مرتبط', 'type' => 'textarea'],
        'impersonationBenefit' => ['label' => 'منفعت یا اقدامی که با آن انجام شده', 'type' => 'textarea'],
      ]
    ],
    'scenario-40' => [
      'label' => 'قاچاق',
      'fields' => [
        'traffickingGoods' => ['label' => 'کالا، شخص یا موضوع مورد قاچاق', 'type' => 'textarea'],
        'traffickingRoute' => ['label' => 'مبدأ، مقصد یا مسیر مرتبط', 'type' => 'textarea'],
        'traffickingIntent' => ['label' => 'قصد قاچاق', 'type' => 'select', 'items' => ['قاچاق اعضای بدن', 'جنسی', 'اتباع']],
      ]
    ],
    'scenario-41' => [
      'label' => 'مواد مخدر',
      'fields' => [
        'drugType' => ['label' => 'نوع مواد', 'type' => 'textarea'],
        'drugQuantity' => ['label' => 'مقدار مواد', 'type' => 'textarea'],
        'drugCultivatorProducer' => ['label' => 'آیا فرد مرتبط، کاشت یا تولید کننده است؟', 'type' => 'choices', 'items' => ['بله', 'خیر', 'نامشخص']],
        'drugStudentInvolvement' => ['label' => 'دانش‌آموزان درگیر هستند؟', 'type' => 'choices', 'items' => ['بله', 'خیر', 'نامشخص']],
        'drugTransit' => ['label' => 'مسیر، محل نگهداری یا جابه‌جایی', 'type' => 'textarea'],
      ]
    ],
    'scenario-42' => [
      'label' => 'خودکشی',
      'fields' => [
        'selfHarmPerson' => ['label' => 'مشخصات فرد یا افراد مرتبط', 'type' => 'textarea'],
        'selfHarmStatus' => ['label' => 'وضعیت فعلی یا محل رخداد', 'type' => 'textarea'],
        'selfHarmSigns' => ['label' => 'نشانه‌ها یا دلایل احتمالی مشاهده‌شده', 'type' => 'textarea'],
      ]
    ],
    'scenario-43' => [
      'label' => 'تهدید و اکراه',
      'fields' => [
        'threatTarget' => ['label' => 'فرد یا گروه مورد تهدید', 'type' => 'textarea'],
        'threatMethod' => ['label' => 'شیوه یا محتوای تهدید', 'type' => 'textarea'],
        'threatDemand' => ['label' => 'خواسته یا نتیجه موردنظر', 'type' => 'textarea'],
      ]
    ],
    'scenario-44' => [
      'label' => 'حوادث و سوانح عمدی',
      'fields' => [
        'intentionalIncidentPlace' => ['label' => 'محل یا هدف حادثه', 'type' => 'textarea'],
        'intentionalIncidentAction' => ['label' => 'اقدام یا روند مشاهده‌شده', 'type' => 'textarea'],
        'intentionalIncidentDamage' => ['label' => 'خسارت یا آسیب ایجادشده', 'type' => 'textarea'],
      ]
    ],
    'scenario-45' => [
      'label' => 'امور امنیتی و غیر‌مجاز',
      'fields' => [
        'unauthorizedSecurityMatter' => ['label' => 'موضوع امنیتی مشاهده‌شده', 'type' => 'textarea'],
        'unauthorizedSecurityLocation' => ['label' => 'محل یا حوزه مرتبط', 'type' => 'textarea'],
        'unauthorizedSecuritySigns' => ['label' => 'نشانه‌ها یا رفتار غیرمجاز', 'type' => 'textarea'],
      ]
    ],
    'scenario-46' => [
      'label' => 'امور خاص اتباع بیگانه',
      'fields' => [
        'foreignPerson' => ['label' => 'مشخصات تبعه یا افراد مرتبط', 'type' => 'textarea'],
        'foreignStatus' => ['label' => 'وضعیت اقامت یا مدرک مرتبط', 'type' => 'textarea'],
        'foreignActivity' => ['label' => 'فعالیت یا محل مرتبط', 'type' => 'textarea'],
      ]
    ],
    'scenario-47' => [
      'label' => 'جرائم مالی و اقتصادی',
      'fields' => [
        'financialEconomicSubject' => ['label' => 'موضوع مالی یا اقتصادی', 'type' => 'textarea'],
        'financialEconomicMethod' => ['label' => 'روش یا اقدام مشاهده‌شده', 'type' => 'textarea'],
        'financialEconomicAmount' => ['label' => 'مبلغ، حجم یا زیان احتمالی', 'type' => 'textarea'],
      ]
    ],
    'scenario-48' => [
      'label' => 'جرائم و تخلفات راهور',
      'fields' => [
        'roadViolationVehicle' => ['label' => 'وسیله نقلیه یا راننده مرتبط', 'type' => 'textarea'],
        'roadViolationLocation' => ['label' => 'محل یا مسیر وقوع', 'type' => 'textarea'],
        'roadViolationRisk' => ['label' => 'خطر یا پیامد ایجادشده', 'type' => 'textarea'],
      ]
    ],
    'scenario-49' => [
      'label' => 'تخلفات و جرائم صنفی',
      'fields' => [
        'businessUnit' => ['label' => 'واحد یا صنف مرتبط', 'type' => 'textarea'],
        'businessViolation' => ['label' => 'تخلف یا اقدام مشاهده‌شده', 'type' => 'textarea'],
        'businessAddress' => ['label' => 'نشانی یا محل فعالیت', 'type' => 'textarea'],
      ]
    ],
    'scenario-50' => [
      'label' => 'جرائم ملکی',
      'fields' => [
        'realEstateSubject' => ['label' => 'ملک یا حق مورد اختلاف', 'type' => 'textarea'],
        'realEstateParties' => ['label' => 'افراد یا مجموعه‌های مرتبط', 'type' => 'textarea'],
        'realEstateClaim' => ['label' => 'اقدام، ادعا یا وضعیت مشاهده‌شده', 'type' => 'textarea'],
      ]
    ],
    'scenario-51' => [
      'label' => 'اختلافات خانوادگی',
      'fields' => [
        'familyMembers' => ['label' => 'افراد خانواده یا وابستگان مرتبط', 'type' => 'textarea'],
        'familyDispute' => ['label' => 'موضوع اختلاف یا رفتار مشاهده‌شده', 'type' => 'textarea'],
        'familyRisk' => ['label' => 'خطر یا نیاز فوری احتمالی', 'type' => 'textarea'],
      ]
    ],
    'scenario-52' => [
      'label' => 'انفجار',
      'fields' => [
        'explosionLocation' => ['label' => 'محل انفجار', 'type' => 'textarea'],
        'explosionCause' => ['label' => 'علت یا نشانه‌های انفجار', 'type' => 'textarea'],
        'explosionDamage' => ['label' => 'خسارت یا آسیب مشاهده‌شده', 'type' => 'textarea'],
      ]
    ],
    'scenario-53' => [
      'label' => 'آتش‌سوزی',
      'fields' => [
        'fireLocation' => ['label' => 'محل آتش‌سوزی', 'type' => 'textarea'],
        'fireCause' => ['label' => 'علت یا منشأ احتمالی آتش', 'type' => 'textarea'],
        'fireDamage' => ['label' => 'گسترش آتش یا خسارت مشاهده‌شده', 'type' => 'textarea'],
      ]
    ],
    'scenario-54' => [
      'label' => 'سرقت',
      'fields' => [
        'theftSubject' => ['label' => 'مال یا محل مورد سرقت', 'type' => 'textarea'],
        'theftOpportunityReason' => ['label' => 'به چه دلیل امکان سرقت وجود دارد', 'type' => 'textarea'],
        'theftDetails' => ['label' => 'جزئیات یا نشانه‌های سرقت', 'type' => 'textarea'],
      ]
    ],
    'scenario-55' => [
      'label' => 'نزاع دسته‌جمعی',
      'fields' => [
        'groupFightLocation' => ['label' => 'محل درگیری', 'type' => 'textarea'],
        'groupFightPeopleCount' => ['label' => 'تعداد یا مشخصات افراد درگیر', 'type' => 'textarea'],
        'groupFightWeapons' => ['label' => 'سلاح یا ابزار استفاده‌شده', 'type' => 'textarea'],
        'groupFightActions' => ['label' => 'روند یا اقدامات مشاهده‌شده', 'type' => 'textarea'],
      ]
    ],
    'scenario-56' => [
      'label' => 'فروش مواد مخدر',
      'fields' => [
        'drugSaleType' => ['label' => 'نوع مواد', 'type' => 'textarea'],
        'drugSaleAmount' => ['label' => 'مقدار مواد', 'type' => 'textarea'],
        'drugSaleLocation' => ['label' => 'محل فروش یا نگهداری', 'type' => 'textarea'],
        'drugSalePeople' => ['label' => 'مشخصات فروشنده یا خریدار', 'type' => 'textarea'],
      ]
    ],
    'scenario-57' => [
      'label' => 'فروش مشروبات الکلی',
      'fields' => [
        'alcoholSaleType' => ['label' => 'نوع مشروبات', 'type' => 'textarea'],
        'alcoholSaleAmount' => ['label' => 'مقدار یا تعداد', 'type' => 'textarea'],
        'alcoholSaleLocation' => ['label' => 'محل فروش یا نگهداری', 'type' => 'textarea'],
        'alcoholSalePeople' => ['label' => 'مشخصات فروشنده یا خریدار', 'type' => 'textarea'],
      ]
    ],
    'scenario-58' => [
      'label' => 'قاچاق انسان',
      'fields' => [
        'humanTraffickingPeople' => ['label' => 'مشخصات افراد یا قربانیان', 'type' => 'textarea'],
        'humanTraffickingRoute' => ['label' => 'مبدأ، مقصد یا مسیر', 'type' => 'textarea'],
        'humanTraffickingMethod' => ['label' => 'روش یا نشانه‌های جابه‌جایی', 'type' => 'textarea'],
        'humanTraffickingPurpose' => ['label' => 'هدف احتمالی انتقال', 'type' => 'textarea'],
      ]
    ],
    'scenario-59' => [
      'label' => 'قاچاق سلاح و مهمات',
      'fields' => [
        'armsTraffickingItems' => ['label' => 'نوع سلاح یا مهمات', 'type' => 'textarea'],
        'armsTraffickingQuantity' => ['label' => 'مقدار یا تعداد', 'type' => 'textarea'],
        'armsTraffickingRoute' => ['label' => 'مبدأ، مقصد یا مسیر', 'type' => 'textarea'],
        'armsTraffickingPeople' => ['label' => 'مشخصات افراد مرتبط', 'type' => 'textarea'],
      ]
    ],
    'scenario-60' => [
      'label' => 'احتکار',
      'fields' => [
        'hoardingGoods' => ['label' => 'نوع کالا یا اقلام', 'type' => 'textarea'],
        'hoardingQuantity' => ['label' => 'مقدار یا حجم', 'type' => 'textarea'],
        'hoardingLocation' => ['label' => 'محل انبار یا نگهداری', 'type' => 'textarea'],
        'hoardingEvidence' => ['label' => 'نشانه‌های احتکار', 'type' => 'textarea'],
      ]
    ],
    'scenario-61' => [
      'label' => 'خانه فساد',
      'fields' => [
        'viceHouseLocation' => ['label' => 'محل یا نشانی', 'type' => 'textarea'],
        'viceHouseActivity' => ['label' => 'فعالیت یا رفتار مشاهده‌شده', 'type' => 'textarea'],
        'viceHousePeople' => ['label' => 'مشخصات افراد مرتبط', 'type' => 'textarea'],
        'viceHouseEvidence' => ['label' => 'نشانه‌ها یا شواهد', 'type' => 'textarea'],
      ]
    ],
  ];
  return $definitions;
}

function normalizedIncidentAnswer($value, string $label): string {
  if (!is_scalar($value)) {
    throw new InvalidArgumentException('پاسخ «' . $label . '» نامعتبر است.');
  }
  $answer = trim((string)$value);
  if ($answer === '' || strlen($answer) > 6000) {
    throw new InvalidArgumentException('پاسخ «' . $label . '» را وارد کنید.');
  }
  return $answer;
}

function normalizeIncidentScenario(array &$form): void {
  // One or more titles may be selected, but every one must have been approved
  // by the hidden scenario allowlist and contain all of its required answers.
  unset($form['crimeType'], $form['crimeMethod'], $form['crimePlace'], $form['crimeDate']);
  if (!isset($form['incident']) || !is_array($form['incident'])) {
    throw new InvalidArgumentException('شرح مشاهده را در دستیار وارد و تحلیل کنید تا سناریو و اطلاعات گزارش وقوع تکمیل شود.');
  }

  $definitions = incidentScenarioDefinitions();
  $incident = $form['incident'];
  $crimeTypes = $incident['crimeTypes'] ?? null;
  if (!is_array($crimeTypes) || count($crimeTypes) < 1 || count($crimeTypes) > count($definitions)) {
    throw new InvalidArgumentException('حداقل یک سناریوی تشخیص‌داده‌شده از متن لازم است.');
  }

  $normalized = ['crimeTypes' => []];
  foreach ($crimeTypes as $candidateTopicId => $submittedAnswers) {
    $topicId = (string)$candidateTopicId;
    if (!array_key_exists($topicId, $definitions) || !is_array($submittedAnswers)) {
      throw new InvalidArgumentException('سناریوی تشخیص‌داده‌شده نامعتبر است.');
    }
    $definition = $definitions[$topicId];
    $answers = ['__label' => $definition['label']];
    foreach ($definition['fields'] as $key => $field) {
      if (!array_key_exists($key, $submittedAnswers)) {
        throw new InvalidArgumentException('پاسخ «' . $field['label'] . '» را وارد کنید.');
      }
      $answer = normalizedIncidentAnswer($submittedAnswers[$key], $field['label']);
      if (isset($field['items']) && !in_array($answer, $field['items'], true)) {
        throw new InvalidArgumentException('گزینهٔ «' . $field['label'] . '» نامعتبر است.');
      }
      $answers[$key] = $answer;
    }
    $normalized['crimeTypes'][$topicId] = $answers;
  }

  if (isset($incident['related'])) {
    if (!is_array($incident['related'])) {
      throw new InvalidArgumentException('اطلاعات افراد مرتبط نامعتبر است.');
    }
    $relatedPeople = $incident['related']['relatedPeople'] ?? null;
    if ($relatedPeople !== null) {
      $relatedPeople = normalizedIncidentAnswer($relatedPeople, 'همکاران و افراد مرتبط');
      $normalized['related'] = ['relatedPeople' => $relatedPeople];
    }
  }

  if (!isset($incident['source']) || !is_array($incident['source'])) {
    throw new InvalidArgumentException('نحوه اطلاع را وارد کنید.');
  }
  if (!array_key_exists('sourceDescription', $incident['source'])) {
    throw new InvalidArgumentException('نحوه اطلاع را وارد کنید.');
  }
  $normalized['source'] = [
    'sourceDescription' => normalizedIncidentAnswer($incident['source']['sourceDescription'], 'نحوه اطلاع')
  ];
  if (!isset($incident['narrative']) || !is_scalar($incident['narrative'])) {
    throw new InvalidArgumentException('شرح مشاهده را در دستیار صوتی یا متنی وارد کنید.');
  }
  $narrative = trim((string)$incident['narrative']);
  if ($narrative === '') {
    throw new InvalidArgumentException('شرح مشاهده را در دستیار صوتی یا متنی وارد کنید.');
  }
  if (!isset($incident['analyzedNarrative']) || !is_scalar($incident['analyzedNarrative']) || trim((string)$incident['analyzedNarrative']) !== $narrative) {
    throw new InvalidArgumentException('شرح مشاهده را با «تحلیل و پرکردن خودکار» بررسی کنید.');
  }
  $normalized['narrative'] = substr($narrative, 0, 12000);
  $form['incident'] = $normalized;
}
function normalize(array $input): array {
  $category = clean($input['category'] ?? null);
  if (!$category) throw new InvalidArgumentException('موضوع گزارش مشخص نشده است.');

  // نام‌های پیشین برای نسخه‌های ذخیره‌شده یا مرورگرهای دارای کش، به عنوان جدید یکپارچه می‌شوند.
  $categoryAliases = [
    'فرد' => 'افراد',
    'ملک' => 'املاک',
    'اماکن' => 'املاک',
    'شیء' => 'اشیاء',
    'پدیده اجتماعی' => 'رویداد'
  ];
  $category = $categoryAliases[$category] ?? $category;

  $allowedCategories = ['افراد', 'املاک', 'اشیاء', 'رویداد'];
  if (!in_array($category, $allowedCategories, true)) {
    throw new InvalidArgumentException('موضوع گزارش نامعتبر است.');
  }

  $subtype = clean($input['subtype'] ?? null);
  $form = is_array($input['form'] ?? null) ? $input['form'] : [];
  // فیلدهای حذف‌شده در نسخه‌های قدیمی یا ارسال دستی ذخیره نمی‌شوند.
  unset(
    $form['priority'],
    $form['weight'],
    $form['crimeType'],
    $form['crimeMethod'],
    $form['crimePlace'],
    $form['crimeDate']
  );
  if ($category === 'املاک') normalizePropertyFields($form);
  normalizePeopleLandlines($form, $category);
  normalizeSocialLinks($form);
  normalizeIncidentScenario($form);
  if (!formHasMeaningfulValue($form)) {
    throw new InvalidArgumentException('اطلاعات گزارش وارد نشده است.');
  }
  validateFormFields($form, $category);
  if ($category === 'رویداد' && $subtype === 'تجمع، تحصن یا اغتشاش' && formValue($form, 'participantMotivation') === null) {
    throw new InvalidArgumentException('انگیزه شرکت‌کنندگان را وارد کنید.');
  }

  $location = is_array($input['location'] ?? null) ? $input['location'] : [];
  normalizeLocationDetailFields($location);
  if ($category === 'املاک') normalizePropertyLocation($location);

  $report = [
    'reportType' => 'گزارش',
    'category' => $category,
    'subtype' => $subtype,
    'form' => $form,
    'location' => $location,
    'time' => is_array($input['time'] ?? null) ? $input['time'] : []
  ];

  if (isset($input['documents']) && is_array($input['documents'])) {
    if (count($input['documents']) > 10) {
      throw new InvalidArgumentException('حداکثر ۱۰ فایل قابل بارگذاری است.');
    }
    $documents = [];
    $documentTotalBytes = 0;
    foreach ($input['documents'] as $document) {
      if (!is_array($document)) continue;
      $name = isset($document['name']) && is_string($document['name']) ? trim($document['name']) : '';
      $data = isset($document['data']) && is_string($document['data']) ? $document['data'] : '';
      if ($name === '' || strlen($name) > 255 || $data === '') {
        throw new InvalidArgumentException('مشخصات فایل بارگذاری‌شده نامعتبر است.');
      }
      if (!preg_match('#^data:([^;,]+)(?:;[^,]*)*;base64,([A-Za-z0-9+/=]*)$#', $data, $matches)) {
        throw new InvalidArgumentException('محتوای فایل بارگذاری‌شده نامعتبر است.');
      }
      $contents = base64_decode($matches[2], true);
      if ($contents === false) {
        throw new InvalidArgumentException('محتوای فایل بارگذاری‌شده نامعتبر است.');
      }
      $decodedBytes = strlen($contents);
      $documentTotalBytes += $decodedBytes;
      if ($documentTotalBytes > MAX_DOCUMENT_TOTAL_BYTES) {
        throw new InvalidArgumentException('مجموع حجم مستندات نباید بیشتر از ۱۰۰ مگابایت باشد.');
      }
      $mime = strtolower($matches[1]);
      $documents[] = [
        'type' => str_starts_with($mime, 'image/') ? 'image' : 'file',
        'name' => $name,
        'mime' => $mime,
        'size' => $decodedBytes,
        'data' => $data
      ];
    }
    $report['documents'] = $documents;
  }

  return $report;
}

function handleReportRequest(): void {
  if ($_SERVER['REQUEST_METHOD'] !== 'POST') return;

  $input = json_decode(file_get_contents('php://input') ?: '', true);
  if (!is_array($input)) jsonResponse(['ok' => false, 'message' => 'اطلاعات ارسالی نامعتبر است'], 400);

  try {
    $report = normalize($input);
  } catch (Throwable $error) {
    jsonResponse(['ok' => false, 'message' => $error->getMessage()], 422);
  }

  $report['id'] = bin2hex(random_bytes(8));
  $report['created_at'] = date('c');

  // اگر پایگاه دادهٔ SQL پیکربندی شده باشد، گزارش در آن ذخیره می‌شود؛
  // در غیر این صورت (یا در صورت خطای اتصال) به فایل JSON بازمی‌گردیم.
  require_once __DIR__ . '/db.php';
  $databaseId = saveReportToDatabase($report);
  if ($databaseId !== null) {
    jsonResponse(['ok' => true, 'message' => 'گزارش با موفقیت ثبت شد', 'report' => $report]);
  }

  $file = __DIR__ . '/../data/reports.json';
  $reports = [];
  if (is_file($file)) {
    $oldReports = json_decode(file_get_contents($file) ?: '', true);
    if (is_array($oldReports)) $reports = $oldReports;
  }
  $reports[] = $report;

  $json = json_encode($reports, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
  if ($json === false || file_put_contents($file, $json, LOCK_EX) === false) {
    jsonResponse(['ok' => false, 'message' => 'ذخیره گزارش انجام نشد'], 500);
  }
  jsonResponse(['ok' => true, 'message' => 'گزارش با موفقیت ثبت شد', 'report' => $report]);
}
